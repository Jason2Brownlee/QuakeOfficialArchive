

@interface TextureView:View
{
	id	parent_i;
	int	deselectIndex;
}

- setParent:(id)from;
- deselect;

@end
