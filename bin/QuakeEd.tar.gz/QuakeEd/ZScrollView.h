#import <appkit/appkit.h>

@interface ZScrollView : ScrollView
{
	id	button1;
}

- initFrame:(const NXRect *)frameRect button1: b1;
- tile;

@end