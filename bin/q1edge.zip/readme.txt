Map:  Q1EDGE
Author:  Tim Willits  
Company:  id Software
Game: Quake 1
Single Player: No
Deathmatch: Yes

Unzip into your quake1\id1\maps directory.

Description:  This map was originally built for the Quake 1 arcade game, a conversion
of "The Edge" for Quake2. I added some teleporters to it in hopes of speeding up
gameplay and help prevent camping. 

For those of you who like to play Quake 1 I hope you enjoy this map.

****This is a fixed version of the map. The map name is now The Edge Conversion.




