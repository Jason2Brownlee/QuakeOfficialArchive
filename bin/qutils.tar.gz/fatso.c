#include <stdio.h>
#include <string.h>

// this program scans the symbol file to find large static objects

#define NUM_TO_REPORT	30

int smallest_fatso;
int top_ten_fatso_sizes[NUM_TO_REPORT];
char top_ten_fatso_names[NUM_TO_REPORT][256];

int main(int argc, char **argv)
{

	char last_name[256];
	char name[256];
	char buffer[256];
	char type[2];
	int last_loc;
	int loc;
	int size;
	int rc;
	int i, j;
	FILE *f;

	f = fopen("dos/sym_dos", "r");
	if (!f)
	{
		fprintf(stderr, "Could not find dos/sym_dos\n");
		return -1;
	}

	memset(top_ten_fatso_sizes, 0, sizeof top_ten_fatso_sizes);
	smallest_fatso = 0;
	last_loc = 0;
	strcpy(last_name, "[dos stub]");

	while (fgets(buffer, sizeof buffer, f))
	{
		rc = strlen(buffer);
		buffer[rc-1] = 0;
		rc = sscanf(buffer, "%x %s %s", &loc, type, name);
		if (rc < 3)
		{
			fprintf(stderr, "bad line : [%s]\n", buffer);
			continue;
		}
		size = loc - last_loc;
		if (size > top_ten_fatso_sizes[smallest_fatso])
		{
			top_ten_fatso_sizes[smallest_fatso] = size;
			strcpy(top_ten_fatso_names[smallest_fatso], last_name);
			for (i=0 ; i<NUM_TO_REPORT ; i++)
			{
				if (top_ten_fatso_sizes[i]
					< top_ten_fatso_sizes[smallest_fatso])
					smallest_fatso = i;
			}
		}
		strcpy(last_name, name);
		last_loc = loc;
	}

	for (j=0 ; j<NUM_TO_REPORT ; j++)
	{
		printf("%8d bytes : [%s]\n", top_ten_fatso_sizes[smallest_fatso],
			top_ten_fatso_names[smallest_fatso]);
		top_ten_fatso_sizes[smallest_fatso] = 0x7fffffff;
		for (i=0 ; i<NUM_TO_REPORT ; i++)
		{
			if (top_ten_fatso_sizes[i] < top_ten_fatso_sizes[smallest_fatso])
				smallest_fatso = i;
		}
	}

	return 0;

}
