#ifndef __MATHLIB__
#define __MATHLIB__

#include "cmdlib.h"

// mathlib.h

typedef float vec_t;
typedef vec_t vec3_t[3];

typedef struct
{
	vec3_t	origin;	// should be intersection of normal through origin
	vec3_t	normal;	// should be normalized
} plane_t;

typedef struct
{
	vec3_t	origin;
	vec3_t	vector;
} line_t;


#define	SIDE_FRONT		1
#define	SIDE_ON			0
#define	SIDE_BACK		-1
#define	SIDE_CROSS		-2

extern vec3_t vec3_origin;

boolean VectorCompare (vec3_t v1, vec3_t v2);

void CrossProduct (vec3_t v1, vec3_t v2, vec3_t cross);
vec_t DotProduct (vec3_t v1, vec3_t v2);
void VectorSubtract (vec3_t va, vec3_t vb, vec3_t out);
void VectorAdd (vec3_t va, vec3_t vb, vec3_t out);
void VectorCopy (vec3_t in, vec3_t out);
void VectorNormalize (vec3_t v);
void VectorInverse (vec3_t v);
void VectorScale (vec3_t v, vec_t scale);
int	PointOnPlaneSide (vec3_t pt, plane_t *plane);
int	PointOnPlaneSideFudge (vec3_t pt, plane_t *plane);
void LineHitPlane (line_t *line, plane_t *plane, vec3_t point);

#endif
