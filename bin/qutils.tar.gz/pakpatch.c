// pakpatch.c

// THIS IS NOT A FUNCTIONAL PROGRAM YET

#include "cmdlib.h"

typedef struct
{
	char	name[56];
	int		filepos, filelen;
} packfile_t;

typedef struct
{
	char	id[4];
	int		dirofs;
	int		dirlen;
} packheader_t;


typedef struct
{
	int				file;
	packheader_t	header;
	int				numfiles;
	packfile_t		*lumps;
} apack_t;

apack_t	*orig, *patch;

apack_t *OpenPackfile (char	*name)
{
	apack_t	*p;
	char	fname[1024];
	int		i;

	p = malloc(sizeof(*p));
	strcpy (fname, name);
	DefaultExtension (fname, "pak");
	
	p->file = SafeOpenRead (fname);
	SafeRead (p->file, &p->header, sizeof(p->header));
	p->header.dirofs = LittleLong (p->header.dirofs);
	p->header.dirlen = LittleLong (p->header.dirlen);

	p->lumps = malloc(p->header.dirlen);

	lseek (p->file, SEEK_SET, p->header.dirofs);
	SafeRead (p->file, p->lumps, p->header.dirlen);
	
	p->numfiles = p->header.dirlen / sizeof(packfile_t);
	
	for (i=0 ; i<p->numfiles ; i++)
	{
		p->lumps[i].filepos = LittleLong ( p->lumps[i].filepos );
		p->lumps[i].filelen = LittleLong ( p->lumps[i].filelen );
	}
	
	printf ("%i files in %s\n",p->numfiles, fname);

	return p;
}


void OpenNew (void)
{
}

void main (int argc, char **argv)
{
	int		i, j;

	if (argc < 3)
		Error ("usage: pakpatch <original> <patch>");

	orig = OpenPackfile (argv[1]);
	patch = OpenPackfile (argv[2]);
		
	OpenNew ();
	
}
