Read the files qspynote and qwrlnote before playing, please.

 - Jack
