---------------------------
Release Notes (April.13.97)
---------------------------

 This is an upgrade to the QuakeWorld Client 1.50. Please overwrite your
\quake\qwcl.exe with the contents of this archive.

