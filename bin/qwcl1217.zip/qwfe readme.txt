QuakeWorld Front End (QWFE)

INSTALLATION:
-------------

You must have QuakeWorld installed in your Quake directory
to use this!

* If you have never installed QSpy previously, then
  install all files into your Quake directory.

* If you have a previous installation of QSpy, then
  copy all files BUT the master.dat file into your QSpy
  directory.  Copy the master.dat file into your Quake
  directory.

STARTING THE QWFE:
------------------

The QWFE is actually the old QSpy we all know and love
with QW enhancements.  To start QSpy in the QWFE mode,
either start QSpy as you normally would and then select
the QuakeWorld option on the View menu.

QW.EXE will normally startup in whatever mode (either QSpy
or QWFE) you last exited the program in.

You can use a cmdline override to the QW.EXE program 
(e.g., "QW.EXE /QWFE") to force QW to start up in QWFE mode.

If this is the first time you have run the QWFE you will
need to create a new account.

CREATING A NEW QUAKEWORLD ACCOUNT:
----------------------------------

Six simple steps are required to create and use a
QuakeWorld account

1)  Unlike QSpy the QW front end requires you to be
    connected to the'net to start.

2)  When you start QuakeWorld front end you will be 
    presented with a login window.

    Enter your chosen user name:  This is the alias/nick that
    QW will use during play.

3)  Enter a password into the password field in login window.

    WRITE YOUR PASSWORD DOWN!

4)  Select a master server.  

5)  Click the login Button - you will then be connected to 
    the master server and your account will be created.

6)  If your account is created successfully you'll see a
    window with your User ID in it.

	WRITE YOUR USER ID DOWN!

	You will need both your User ID and password to
	gain access to the master server you selected in the
	future. 

	(QWFE remembers your ID after you've entered it once
	 and will auto login if you set the options in QW
	 options).

You can now use QWFE in the same way you've used QSpy.

When you next log in use your User ID and password - NOT your
user name!

DIFFERENCES BETWEEN QSPY AND QWFE MODE:
---------------------------------------

When in QuakeWorld mode the program functions in much the same
way as usual.  With the following differences:

* Login Dialog

	When you start QSpy in QWFE mode you will be presented
	with a login window (unless you have the auto-login
	QWFE option selected).

* QuakeWorld Menu
	
	There are three additional options under the QSpy
	menu tab:

	1)  Login
	
	    Brings up the QWFE login window - allows you to
	    login as a different player. 

	2)  User Information

	    This window allows you to change your QuakeWorld 
	    player settings.
	
	3)  Player Query

	    Allows you to view the information stored on the
	    master server about another player.  This works
	    exactly the same way as the player settings screen.
	    You can't change anything except the User Number
	    though!

* A QW options tab under View/Options

	Remember QuakeWorld login password

	    Saves and restores the last used password

	Perform Auto-Login upon startup
	
	    Will automatically log you into QuakeWorld, skipping
	    the login dialog.

	Paint colors on skin in User Info dialog

	    Will paint user's top/bottom colors on the selected
	    skin in the User Info / Query dialogs.  If this is
	    not selected, then the skin will be displayed in its
	    normal colors.

	QuakeWorld cmd line

	    Allows you to specify command line options to pass 
	    into the QW Client program.

* Three extra columns on the player list - skin, ping and User ID

	If you double click on a player, the QWFE will
	automatically bring up the Query User dialog with info on
	that player.
