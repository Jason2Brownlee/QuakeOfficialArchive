IMPORTANT!!  Please remember that Quake World is an UNSUPPORTED release.
DO NOT email id Software for technical support.  Refer to the following
TXT files in the QWCL ZIP:

qwfe readme.txt Getting started with the Quake World Front End
qwcl.txt	Command line/console command summary, notes, known bugs
qw-win.txt	Windows-related QuakeWorld information - lot's of
		technical information useful in troubleshooting
qwsv.txt	An updated file for Quake World Server

--------------------------------------
| Installing and running Quake World |
--------------------------------------

1) Unzip the client in your quake directory.
i.e. pkunzip filename

2) From your Quake directory, run the file MFCINST.EXE by either
double-clicking it in Explorer or typing MFCINST at the DOS Prompt

3) You can launch Quake World by following one of two steps:

From a DOS prompt:
- Change to your Quake directory. i.e. cd\quake
- Type QW.EXE /QWFE and hit ENTER

In Windows 95:
- Double click the QW application in your Quake folder
- Go to the View menu and click "QuakeWorld"

4) When QW starts, it will ask you for a login.  First, click on the drop down
arrow next to Master Server and select 192.246.40.115:27000
- Next type the name you wish to use in Quake World in the Name field
- Give your self a password and click Login - you will then be connected to 
  the master server and your account will be created.
- If your account is created successfully you'll see a window with your User ID in it.

5) Click on the Server menu and select Update Server List.  When this completes,
double click on a server in the list to connect!

WRITE YOUR USER ID (a number) AND PASSWORD DOWN!

You will need both your User ID and password to
gain access to the master server you selected in the
future. 

(QWFE remembers your ID after you've entered it once
and will auto login if you set the options in QW
options).

Please see qwfe readme.txt for help on connecting to servers
and general help with the front end.



modified 12/17/96
