#!/bin/sh
for x in *; do
	y=`echo $x | tr '[A-Z]' '[a-z]'`
	if [ $x != $y ]; then
		echo mv $x $y
	fi
done
	
